%INIT_GRAPHICS  Setup the graphics module
%
%   INIT_GRAPHICS should be called ONLY ONCE in the code. It will setup all
%   variables necessary for the graphics visualization to work. This needs
%   to be called before any call to DRAW_GRAPHICS.
%
%   See also draw_graphics.
%
