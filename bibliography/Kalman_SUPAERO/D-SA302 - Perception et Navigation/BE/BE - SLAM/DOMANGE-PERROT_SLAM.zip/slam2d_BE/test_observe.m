%TEST_OBSERVE  Tests if observe.m is correct
%
%   TEST_OBSERVE performs calls to the function observe you will code
%   and tests if it returns what is expected. If the observe.m is not
%   correct this function will tell you so. You should re-work your
%   observe.m until it passes this test!
%
