% SLAM2D  Shows the result of a functional 2D EKF-SLAM.
%
% This function shows the result that is expected from your code. Use it to
% compare to your results.
%
